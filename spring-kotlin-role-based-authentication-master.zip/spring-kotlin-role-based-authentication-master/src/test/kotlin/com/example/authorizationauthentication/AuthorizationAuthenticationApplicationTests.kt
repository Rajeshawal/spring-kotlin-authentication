package com.example.authorizationauthentication

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AuthorizationAuthenticationApplicationTests {

    @Test
    fun contextLoads() {
    }

}
