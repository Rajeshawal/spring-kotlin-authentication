package com.example.authorizationauthentication.payload.response

class MessageResponse(
    val message:String
)