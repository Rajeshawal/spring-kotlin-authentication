package com.example.authorizationauthentication.models

enum class ERole {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_ADMIN
}