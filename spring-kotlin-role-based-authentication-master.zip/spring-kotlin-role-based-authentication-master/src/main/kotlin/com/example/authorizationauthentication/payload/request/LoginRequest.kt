package com.example.authorizationauthentication.payload.request

class LoginRequest(
    val username:String,
    val password:String
)