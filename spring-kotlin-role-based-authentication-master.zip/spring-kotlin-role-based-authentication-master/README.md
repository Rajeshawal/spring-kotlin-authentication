# Role based spring-security in kotlin
This is an example to implement role-based authentication and authorization in springboot application using kotlin.

## Includes
- Spring Security
- JPA 
- Postgres
- JWT

This project is kotlin implementation of role based authorization and authentication in java.

For java implementation follow [this](https://bezkoder.com/spring-boot-security-postgresql-jwt-authentication/)